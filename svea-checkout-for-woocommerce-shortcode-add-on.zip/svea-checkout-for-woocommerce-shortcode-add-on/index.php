<?php // Silence of the lamp
